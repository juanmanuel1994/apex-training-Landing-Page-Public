/* ============================================
   APEX TRAINING — JS
   Mouse-Reactive Gradient Mesh · Nav · Reveal · Form
   ============================================ */

(function () {
  'use strict';

  /* ─────────────────────────────────────────
     1. MOUSE-REACTIVE GRADIENT MESH CANVAS
     ───────────────────────────────────────── */
  const canvas = document.getElementById('gradient-canvas');
  const ctx    = canvas.getContext('2d');

  let W = 0, H = 0;
  let mouse = { x: 0.5, y: 0.5 };         // normalised 0-1
  let target = { x: 0.5, y: 0.5 };        // lerp target
  let t = 0;                                // time for organic drift

  function resize() {
    W = canvas.width  = window.innerWidth;
    H = canvas.height = window.innerHeight;
  }
  window.addEventListener('resize', resize);
  resize();

  window.addEventListener('mousemove', e => {
    target.x = e.clientX / W;
    target.y = e.clientY / H;
  });

  /* Touch support */
  window.addEventListener('touchmove', e => {
    if (e.touches.length) {
      target.x = e.touches[0].clientX / W;
      target.y = e.touches[0].clientY / H;
    }
  }, { passive: true });

  /* Mesh orb definitions  — index, base pos (0-1), colour */
  const orbs = [
    { bx: 0.15, by: 0.25, r: 0.55, color: [57, 255, 20],  influence: 0.45, phase: 0.0  },
    { bx: 0.80, by: 0.70, r: 0.50, color: [30, 140, 10],  influence: 0.35, phase: 2.1  },
    { bx: 0.50, by: 0.50, r: 0.65, color: [20, 80,  8],   influence: 0.25, phase: 4.2  },
    { bx: 0.10, by: 0.80, r: 0.40, color: [57, 255, 20],  influence: 0.20, phase: 1.1  },
    { bx: 0.90, by: 0.15, r: 0.42, color: [38, 179, 13],  influence: 0.22, phase: 3.3  },
  ];

  function lerp(a, b, t) { return a + (b - a) * t; }

  function draw() {
    t += 0.004;

    /* smooth mouse follow */
    mouse.x = lerp(mouse.x, target.x, 0.06);
    mouse.y = lerp(mouse.y, target.y, 0.06);

    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = '#080808';
    ctx.fillRect(0, 0, W, H);

    orbs.forEach(orb => {
      /* organic drift + mouse influence */
      const drift = Math.sin(t + orb.phase) * 0.08;
      const ox = (orb.bx + drift + (mouse.x - 0.5) * orb.influence) * W;
      const oy = (orb.by + Math.cos(t * 0.7 + orb.phase) * 0.06 + (mouse.y - 0.5) * orb.influence) * H;
      const radius = orb.r * Math.min(W, H);

      const grad = ctx.createRadialGradient(ox, oy, 0, ox, oy, radius);
      const [r, g, b] = orb.color;
      grad.addColorStop(0,   `rgba(${r},${g},${b},0.28)`);
      grad.addColorStop(0.4, `rgba(${r},${g},${b},0.10)`);
      grad.addColorStop(1,   `rgba(${r},${g},${b},0)`);

      ctx.globalCompositeOperation = 'screen';
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.ellipse(ox, oy, radius, radius * 0.8, t * 0.1 + orb.phase, 0, Math.PI * 2);
      ctx.fill();
    });

    ctx.globalCompositeOperation = 'source-over';
    requestAnimationFrame(draw);
  }

  draw();


  /* ─────────────────────────────────────────
     2. NAV: SCROLL STATE & ACTIVE LINK
     ───────────────────────────────────────── */
  const nav        = document.getElementById('nav');
  const burger     = document.getElementById('burger');
  const mobileMenu = document.getElementById('mobile-menu');
  const mmLinks    = document.querySelectorAll('.mm-link');

  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 40);
  }, { passive: true });

  burger.addEventListener('click', () => {
    burger.classList.toggle('open');
    mobileMenu.classList.toggle('open');
  });

  mmLinks.forEach(link => {
    link.addEventListener('click', () => {
      burger.classList.remove('open');
      mobileMenu.classList.remove('open');
    });
  });


  /* ─────────────────────────────────────────
     3. SCROLL-REVEAL INTERSECTION OBSERVER
     ───────────────────────────────────────── */
  const revealTargets = [
    '.section-header',
    '.program-card',
    '.trainer-card',
    '.plan-card',
    '.contact-left',
    '.contact-form',
    '.hero-stats',
    '.footer-brand',
    '.footer-col',
  ];

  const io = new IntersectionObserver((entries) => {
    entries.forEach(el => {
      if (el.isIntersecting) {
        el.target.classList.add('visible');
        io.unobserve(el.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

  revealTargets.forEach(sel => {
    document.querySelectorAll(sel).forEach((el, i) => {
      el.classList.add('reveal');
      el.style.transitionDelay = `${i * 80}ms`;
      io.observe(el);
    });
  });


  /* ─────────────────────────────────────────
     4. HERO TEXT STAGGER ON LOAD
     ───────────────────────────────────────── */
  const heroLines = document.querySelectorAll('.title-line');
  const heroSub   = document.querySelector('.hero-sub');
  const heroEye   = document.querySelector('.hero-eyebrow');
  const heroActs  = document.querySelector('.hero-actions');
  const heroStats = document.querySelector('.hero-stats');

  const heroItems = [heroEye, ...heroLines, heroSub, heroActs, heroStats];

  heroItems.forEach(el => {
    if (!el) return;
    el.style.opacity = '0';
    el.style.transform = 'translateY(28px)';
    el.style.transition = 'opacity .8s cubic-bezier(.4,0,.2,1), transform .8s cubic-bezier(.4,0,.2,1)';
  });

  window.addEventListener('load', () => {
    heroItems.forEach((el, i) => {
      if (!el) return;
      setTimeout(() => {
        el.style.opacity = '1';
        el.style.transform = 'translateY(0)';
      }, 100 + i * 120);
    });
  });


  /* ─────────────────────────────────────────
     5. PROGRAM CARD MAGNETIC TILT
     ───────────────────────────────────────── */
  document.querySelectorAll('.program-card').forEach(card => {
    card.addEventListener('mousemove', e => {
      const rect = card.getBoundingClientRect();
      const cx   = rect.left + rect.width  / 2;
      const cy   = rect.top  + rect.height / 2;
      const dx   = (e.clientX - cx) / (rect.width  / 2);
      const dy   = (e.clientY - cy) / (rect.height / 2);
      card.style.transform = `perspective(600px) rotateX(${-dy * 4}deg) rotateY(${dx * 4}deg) translateZ(4px)`;
    });
    card.addEventListener('mouseleave', () => {
      card.style.transform = '';
      card.style.transition = 'transform .4s cubic-bezier(.4,0,.2,1), background .3s';
    });
  });


  /* ─────────────────────────────────────────
     6. TRAINER CARD PARALLAX
     ───────────────────────────────────────── */
  document.querySelectorAll('.trainer-card').forEach(card => {
    card.addEventListener('mousemove', e => {
      const rect = card.getBoundingClientRect();
      const dx   = (e.clientX - rect.left) / rect.width  - 0.5;
      const dy   = (e.clientY - rect.top)  / rect.height - 0.5;
      card.style.transform = `perspective(800px) rotateX(${-dy * 5}deg) rotateY(${dx * 5}deg) translateY(-6px)`;
    });
    card.addEventListener('mouseleave', () => {
      card.style.transform = '';
      card.style.transition = 'transform .5s cubic-bezier(.4,0,.2,1), border-color .3s';
    });
  });


  /* ─────────────────────────────────────────
     7. CONTACT FORM SUBMIT
     ───────────────────────────────────────── */
  const form = document.getElementById('contact-form');

  if (form) {
    form.addEventListener('submit', e => {
      e.preventDefault();

      const btn   = form.querySelector('.form-submit');
      const orig  = btn.textContent;
      btn.textContent = 'Sending…';
      btn.disabled = true;

      setTimeout(() => {
        /* Inject success message */
        const successDiv = document.createElement('div');
        successDiv.className = 'form-success';
        successDiv.innerHTML = `
          <svg viewBox="0 0 48 48" fill="none">
            <circle cx="24" cy="24" r="20" stroke="currentColor" stroke-width="2.5"/>
            <path d="M15 24l7 7 11-14" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>Message sent! We'll be in touch within 24 hours.</span>`;

        form.innerHTML = '';
        form.appendChild(successDiv);
        form.style.minHeight = '300px';
        form.style.display = 'flex';
        form.style.alignItems = 'center';
        form.style.justifyContent = 'center';

        successDiv.style.opacity = '0';
        successDiv.style.transform = 'translateY(12px)';
        successDiv.style.transition = 'opacity .5s, transform .5s';
        successDiv.style.display = 'flex';

        requestAnimationFrame(() => {
          requestAnimationFrame(() => {
            successDiv.style.opacity = '1';
            successDiv.style.transform = 'translateY(0)';
          });
        });
      }, 900);
    });
  }


  /* ─────────────────────────────────────────
     8. SMOOTH SCROLL OFFSET FOR FIXED NAV
     ───────────────────────────────────────── */
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      const id = a.getAttribute('href').slice(1);
      const target = document.getElementById(id);
      if (!target) return;
      e.preventDefault();
      const top = target.getBoundingClientRect().top + window.scrollY - 72;
      window.scrollTo({ top, behavior: 'smooth' });
    });
  });


  /* ─────────────────────────────────────────
     9. CURSOR NEON GLOW FOLLOWER
     ───────────────────────────────────────── */
  const cursor = document.createElement('div');
  cursor.id = 'cursor-glow';
  Object.assign(cursor.style, {
    position: 'fixed',
    pointerEvents: 'none',
    zIndex: '9999',
    width: '320px',
    height: '320px',
    borderRadius: '50%',
    background: 'radial-gradient(circle, rgba(57,255,20,0.07) 0%, transparent 70%)',
    transform: 'translate(-50%,-50%)',
    transition: 'opacity .3s',
    top: '0', left: '0',
  });
  document.body.appendChild(cursor);

  let cursorPos = { x: -999, y: -999 };

  window.addEventListener('mousemove', e => {
    cursorPos.x = e.clientX;
    cursorPos.y = e.clientY;
  });

  (function animateCursor() {
    cursor.style.left = cursorPos.x + 'px';
    cursor.style.top  = cursorPos.y + 'px';
    requestAnimationFrame(animateCursor);
  })();

  /* Hide on mobile */
  const mq = window.matchMedia('(hover: none)');
  cursor.style.display = mq.matches ? 'none' : 'block';
  mq.addEventListener('change', e => { cursor.style.display = e.matches ? 'none' : 'block'; });

})();
